%%
% analyze.m
% Run analysis of inflammation data files

% Figure out how many files are in directory
contents = dir('inflammation-data/*.csv');
nfiles = length(contents);

for idx = 1:nfiles
    % Create strings for input/output filenames
    infilename = sprintf('inflammation-%02d.csv',idx);
    imgname = sprintf('patient_data_%02d.png',idx);
    
    
    patient_data = csvread(infilename);
    disp(['analyzing ',infilename]);
    disp(['maximum inflammation: ' num2str(max(patient_data(:)))]);
    disp(['minimum inflammation: ' num2str(min(patient_data(:)))]);
    disp(['standard deviation: ' num2str(std(patient_data(:)))]);
    
    % create some plots
    ave_inflammation = mean(patient_data,1);
    subplot(1,3,1);
    plot(ave_inflammation);
    ylabel('Average');
    
    subplot(1,3,2);
    plot(max(patient_data,[],1));
    ylabel('Maximum');
    
    subplot(1,3,3);
    plot(min(patient_data,[],1));
    ylabel('Minimum');
    
    % save plot image to disk as png
    print('-dpng',imgname)
    close()
    
end