vowels = 'aeiou';
n_vowels = 0;
for letter = vowels
    disp([num2str(n_vowels), letter])
    n_vowels = n_vowels + 1;
end
disp(['The number of vowels is : ',num2str(n_vowels)])

exit
