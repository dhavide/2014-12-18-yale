function protein_plot(counts,amino_string,colstoview)
%PROTEIN_PLOT - displays plots of frequencies computed from aligned
%               protein sequences.
% Input: counts - computed array of frequencies
%        amino_string - string indexing amino acids by letter abbrev.
%        cols2view - array of integers of which columns to see

% This is to generate a cell array of strings...
N_amino = length(amino_string);
for k=1:length(amino_string)
  lbls{k} = amino_string(k);
end
% Let's make bar plots of the first three columns
for col = colstoview
  figure(col) % Make new figure window
  bar(counts(:,col)), shg  % Produces a bar plot.
  % tstring is used to embed the position number into the title of plot
  tstring = sprintf('Frequencies in position %d',col);
  title(tstring)
  % Magic commands to label horizontal axis meaningfully
  set(gca,'Xtick',1:N_amino);
  set(gca,'XTickLabel', lbls);
  axis tight
end
end