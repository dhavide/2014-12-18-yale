function [counts, amino_string] = protein_analyse(filename)
%PROTEIN_ANALYSE - compute frequencies of amino acids by position from file
% Input: filename
% Output: counts - array of frequencies of amino acids in positions
%                  as counted from aligned sequences in filename
%         amino_string - string of abbreviations of amino acids

% Invoke protein_reader to load data into memory from file
sequences = protein_reader(filename);
[N_seq,N_pos] = size(sequences);

% Construct a string for the amino acids to index counts array
amino_string = 'ACDEFGHIKLMNPQRSTVWY';
N_amino = length(amino_string); % Number of amino acids

% Preallocate space for array of counts
counts = zeros(N_amino,N_pos); % creates array of all zeros

% As a first step, print small submatrix to analyse
for k_seq = 1:N_seq
    for k_pos = 1:N_pos
        % Identify the row index of the amino acid table
        amino_row = strfind(amino_string, sequences{k_seq,k_pos});
        % Increment counter for appropriate amino acid in this position
        counts(amino_row,k_pos) = counts(amino_row,k_pos) + 1;
    end
end
% Normalise to get frequencies...
counts = counts / N_seq;
end